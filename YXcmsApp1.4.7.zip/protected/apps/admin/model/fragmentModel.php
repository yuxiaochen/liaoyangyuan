<?php
class fragmentModel extends baseModel{
	protected $table = 'fragment';
}