<?php
class pageModel extends baseModel{
	protected $table = 'page';
}