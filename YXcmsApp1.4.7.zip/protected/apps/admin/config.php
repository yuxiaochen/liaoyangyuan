<?php
return array(
    'APP_STATE' => 1,
    'APP_NAME' => '网站后台',
    'APP_VER' => '1.0',
    'APP_AUTHOR' => '路过',
    'APP_ORIGINAL_PREFIX' => 'yx_',
    'APP_TABLES' => '',
    'APP' => 
    array (
     'HTML_CACHE_ON' => false,
    ),
	'TPL' => 
    array (
     'TPL_CACHE_ON' => false,
    ),
     'DB' => 
    array (
     'DB_CACHE_ON' => false,
    ),
);
