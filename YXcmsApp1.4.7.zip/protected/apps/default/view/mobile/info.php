<?php return array (
  'name' => 'VIP模板一',
  'author' => 'yx',
); ?>