<!DOCTYPE html>
<html>
<head>
<title>标题</title>
<meta content="IE=8" http-equiv="X-UA-Compatible" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<script type="text/javascript" src="__PUBLIC__/js/jquery.js"></script>
</head>
<body>
<div id="contain">
{include file="$__template_file"}
</div>
</body>
</html>
