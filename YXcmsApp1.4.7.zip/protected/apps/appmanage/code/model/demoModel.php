<?php
class demoModel extends baseModel{
	protected $table = 'demo'; //设置表名
}